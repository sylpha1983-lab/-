# Builder v1.0 – H/C Emotional System

This is the final production-ready snapshot.

Core concepts:
- Holo Emotional Luminance (H0–H4)
- C-Tree Body Temperature (C0–C4)
- World Presets auto-expanded into prompt-ready text
- No warnings, no guidance text, no abstraction leakage

Flow:
Select → Expand → Copy → Generate
