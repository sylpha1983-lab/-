(function(){
  "use strict";
  // patched: disabled to preserve original action layout
  console.log("[ext] disabled: ext_floating_panel.js");
  return;
})();
